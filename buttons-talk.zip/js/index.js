function myFunction() {
var x = document.getElementById("myBtn").value;
document.getElementById("demo").innerHTML = x; 
  
}
  
function myFunction2() {
var x = document.getElementById("myBtn2").value;
document.getElementById("demo").innerHTML = x;
  
}